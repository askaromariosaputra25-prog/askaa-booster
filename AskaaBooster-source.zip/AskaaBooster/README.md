# Askaa Booster

Booster Android untuk Oppo A57 (Android 14) yang sudah di-root. Dibuat untuk dipakai sendiri, bukan untuk Play Store.

## Fitur versi 1

- **Booster otomatis:** saat game yang dipilih dibuka, profil langsung diterapkan. Profil tersedia: Performa, Seimbang, dan Hemat.
- **Simpan dan kembalikan:** setting asli disimpan dulu. Saat game ditutup, setting dikembalikan. Kalau app mati di tengah game, sisa booster dipulihkan saat app jalan lagi.
- **Pengaman suhu:** di 46°C profil Performa turun ke Seimbang. Di 52°C semua setting dikembalikan dan booster diam 2 menit.
- **Monitor:** suhu, frekuensi CPU tertinggi, load, RAM, dan baterai.
- **Pilih game** dari daftar app yang terpasang.
- **Bersihkan background** dengan `am kill-all`.

Belum masuk v1: tombol melayang (overlay), jalan pintas dan tips, donasi QRIS, dan halaman thanks to.

## Struktur folder

```
AskaaBooster/
├── .github/workflows/build.yml   ← build APK otomatis di GitHub
├── app/
│   ├── build.gradle.kts
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── java/com/askaa/booster/
│       │   ├── MainActivity.kt   ← entry point
│       │   ├── HomeScreen.kt     ← layar utama (profil, monitor, tombol)
│       │   ├── GamesScreen.kt    ← pilih game
│       │   ├── BoostService.kt   ← pemantau game dan pengaman suhu
│       │   ├── Tuner.kt          ← baca, terapkan, dan pulihkan setting
│       │   ├── Profile.kt        ← nilai tiap profil
│       │   ├── Monitor.kt        ← baca suhu, CPU, RAM, baterai
│       │   ├── GameDetector.kt   ← deteksi app di foreground
│       │   ├── Prefs.kt          ← penyimpanan setting dan snapshot
│       │   └── RootShell.kt      ← jalankan perintah lewat su
│       └── res/                  ← string, tema, dan icon
├── build.gradle.kts
├── settings.gradle.kts
└── gradle.properties
```

## Langkah 1: Upload ke GitHub

1. Login ke github.com, lalu klik **New** untuk membuat repository.
2. Isi nama `askaa-booster`. Pilih Public atau Private, terserah. **Jangan** centang README, .gitignore, atau license karena sudah ada di folder ini.
3. Upload semua isi folder `AskaaBooster`. Cara termudah: klik **uploading an existing file**, lalu drag seluruh isi folder.
   - Pastikan folder `.github` ikut terupload. Di Windows folder ini tersembunyi, jadi cek lagi setelah upload.
   - Atau pakai git dari terminal:

```bash
cd AskaaBooster
git init
git add .
git commit -m "first commit"
git branch -M main
git remote add origin https://github.com/USERNAME/askaa-booster.git
git push -u origin main
```

Ganti `USERNAME` dengan username GitHub kamu.

## Langkah 2: Build APK otomatis

1. Buka repository, lalu pilih tab **Actions**. Kalau diminta, klik **I understand my workflows, go ahead and enable them**.
2. Pilih workflow **Build APK** di sisi kiri, lalu klik **Run workflow** dan konfirmasi.
3. Tunggu sekitar 5 sampai 10 menit. Build pertama memang lebih lama karena Gradle mengunduh library.
4. Kalau hasilnya hijau ✅, buka run tersebut lalu scroll ke bagian **Artifacts**. Klik **AskaaBooster-debug** untuk mengunduh file zip, di dalamnya ada `app-debug.apk`.
5. Kalau merah ❌, buka log, cari baris yang diawali `e:` (error Kotlin) atau `FAILURE:`. Copy pesannya dan kirim ke saya.

Workflow juga otomatis jalan setiap ada push ke branch `main`.

## Langkah 3: Install di Oppo A57

1. Pindahkan `app-debug.apk` ke HP (lewat kabel, Google Drive, atau Telegram ke diri sendiri).
2. Buka file tersebut lewat File Manager. Kalau diminta, izinkan **Instal aplikasi tidak dikenal** untuk File Manager.
3. Tap **Install**. Kalau ColorOS minta verifikasi tambahan, ikuti saja.
4. Buka Magisk atau KernelSU, lalu pastikan **Askaa Booster** diberi akses root. Saat pertama kali dibuka, popup izin root juga akan muncul, tinggal tap **Allow**.

## Langkah 4: Setting ColorOS (penting)

ColorOS suka mematikan app di background, jadi ini wajib dicek:

- **Pengaturan > Aplikasi > Askaa Booster > Izin:** izinkan Notifikasi.
- **Autostart / Mulai otomatis:** aktifkan.
- **Baterai > Askaa Booster:** pilih **Tanpa pembatasan** atau **Jangan dioptimalkan**.
- Di daftar recent apps, tahan kartu Askaa Booster lalu pilih ikon gembok supaya tidak ikut tertutup saat bersihkan background.

Nama menu bisa sedikit berbeda tergantung versi ColorOS.

## Langkah 5: Cara pakai

1. Buka app, lalu tap **Pilih game** dan centang game yang mau di-boost.
2. Pilih profil di bagian Profil. Yang paling aman untuk awal adalah **Seimbang**.
3. Nyalakan **Aktifkan saat game dibuka**. Notifikasi "Memantau game..." akan muncul.
4. Buka game. Notifikasi akan berubah menjadi "Boost aktif: nama.paket".
5. Tutup game. Setting otomatis kembali ke awal.

Cara tes manual: tap **Terapkan sekarang**, lalu tap **Kembalikan setting awal** untuk memastikan semuanya kembali.

## Build lokal (opsional, pakai Android Studio)

1. Buka Android Studio, lalu pilih **File > Open** dan pilih folder `AskaaBooster`.
2. Tunggu Gradle Sync selesai. Android Studio akan membuat Gradle wrapper sendiri.
3. Pilih **Build > Build App Bundle(s) / APK(s) > Build APK(s)**.
4. APK ada di `app/build/outputs/apk/debug/`.

## Troubleshooting

- **"Root tidak terdeteksi":** pastikan Askaa Booster sudah diberi izin root di Magisk atau KernelSU, lalu buka ulang app.
- **Game tidak terdeteksi:** buka game, lalu jalankan di Termux: `su -c "dumpsys activity activities | grep mResumedActivity"`. Kalau outputnya kosong atau tidak ada nama paket, kirim hasilnya ke saya supaya parser-nya bisa disesuaikan dengan ROM kamu.
- **Booster mati sendiri:** biasanya autostart atau optimasi baterai belum dimatikan. Cek Langkah 4.
- **Perintah DND tidak jalan:** sebagian ROM tidak mendukung `cmd notification set_dnd`. Bagian itu dilewati, fitur lainnya tetap jalan.
- **Suhu cepat naik:** turunkan batas di `BoostService.kt` (`SOFT_LIMIT_C` dan `HARD_LIMIT_C`), atau pakai profil Seimbang sebagai default.

## Catatan jujur

- Kode ini belum saya jalankan di HP asli dan belum dicompile di sini. Kalau build gagal atau ada error saat dipakai, kirim log atau pesan errornya.
- Path sysfs (CPU dan GPU) bisa beda tiap ROM. App hanya menulis governor yang memang tersedia di kernel, jadi yang tidak didukung dilewati dan tidak merusak apa-apa.
- Refresh rate tidak diatur karena ColorOS mengaturnya sendiri.
- Booster memang tidak menjanjikan FPS naik. Efeknya terbatas oleh chip dan suhu HP, jadi yang paling terasa biasanya stabilitas, bukan angka FPS.
