package com.askaa.booster

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Service latar belakang: cek game yang di foreground tiap beberapa detik,
 * terapkan booster saat game dibuka, kembalikan saat game ditutup,
 * dan turunkan profil kalau suhu terlalu tinggi.
 */
class BoostService : Service() {

    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private var loopJob: Job? = null
    private var boosting = false
    private var throttled = false
    private var cooldownUntil = 0L

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val channel = NotificationChannel(CHANNEL, "Askaa Booster", NotificationManager.IMPORTANCE_LOW)
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)

        val notif = buildNotif("Memantau game...")
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, notif)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (loopJob == null) {
            loopJob = scope.launch { loop() }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        if (boosting) restoreNow()
        scope.cancel()
        super.onDestroy()
    }

    private suspend fun loop() {
        // Kalau app/service mati saat booster aktif, pulihkan dulu sebelum lanjut.
        if (Prefs.boosting(this)) restoreNow()
        while (true) {
            runCatching { tick() }
            delay(POLL_MS)
        }
    }

    private fun tick() {
        if (!Prefs.autoBoost(this)) {
            if (boosting) restoreNow()
            return
        }

        val fg = GameDetector.foreground()
        val inGame = fg != null && fg in Prefs.games(this)
        val now = System.currentTimeMillis()

        when {
            inGame && !boosting && now >= cooldownUntil -> {
                Tuner.applyWithSnapshot(this, Prefs.profile(this))
                boosting = true
                throttled = false
                Prefs.setBoosting(this, true)
                updateNotif("Boost aktif: $fg")
            }
            !inGame && boosting -> restoreNow()
            boosting -> guardThermal(now)
        }
    }

    private fun guardThermal(now: Long) {
        val t = Monitor.readTemp() ?: return
        val base = Prefs.profile(this)
        when {
            t >= HARD_LIMIT_C -> {
                restoreNow()
                cooldownUntil = now + COOLDOWN_MS
                updateNotif("Suhu ${t.toInt()}°C, setting dikembalikan")
            }
            t >= SOFT_LIMIT_C && !throttled && base == Profile.PERFORMA -> {
                Tuner.apply(Profile.SEIMBANG)
                throttled = true
                updateNotif("Suhu ${t.toInt()}°C, turun ke Seimbang")
            }
            throttled && t < SOFT_LIMIT_C - 6 -> {
                Tuner.apply(base)
                throttled = false
                updateNotif("Suhu normal, profil ${base.label}")
            }
        }
    }

    private fun restoreNow() {
        Tuner.restoreWithSnapshot(this)
        boosting = false
        throttled = false
        updateNotif("Memantau game...")
    }

    private fun buildNotif(text: String): Notification =
        NotificationCompat.Builder(this, CHANNEL)
            .setContentTitle("Askaa Booster")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .build()

    private fun updateNotif(text: String) {
        getSystemService(NotificationManager::class.java).notify(NOTIF_ID, buildNotif(text))
    }

    companion object {
        private const val NOTIF_ID = 1001
        private const val CHANNEL = "booster_status"
        private const val POLL_MS = 3000L
        private const val SOFT_LIMIT_C = 46f
        private const val HARD_LIMIT_C = 52f
        private const val COOLDOWN_MS = 120_000L

        fun start(ctx: Context) {
            ContextCompat.startForegroundService(ctx, Intent(ctx, BoostService::class.java))
        }

        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, BoostService::class.java))
        }
    }
}
