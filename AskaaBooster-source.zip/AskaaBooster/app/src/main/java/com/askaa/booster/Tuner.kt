package com.askaa.booster

import android.content.Context
import org.json.JSONObject

/** Membaca, menerapkan, dan memulihkan setting sistem lewat root. */
object Tuner {
    private const val CPU_BASE = "/sys/devices/system/cpu/cpufreq"
    private const val GPU_GOV = "/sys/class/kgsl/kgsl-3d0/devfreq/governor"
    private const val GPU_AVAIL = "/sys/class/kgsl/kgsl-3d0/devfreq/available_governors"
    private val ANIM = listOf("window_animation_scale", "transition_animation_scale", "animator_duration_scale")
    private val SAFE = Regex("[A-Za-z0-9_.-]+")

    private fun clean(v: String?): String? =
        v?.trim()?.takeIf { it != "null" && SAFE.matches(it) }

    /** Baca setting asli sekarang. Dipanggil SEBELUM booster mengubah apa pun. */
    fun capture(): JSONObject {
        val j = JSONObject()

        val cpuOut = RootShell.value(
            "for p in $CPU_BASE/policy*; do echo \"\$(basename \$p)=\$(cat \$p/scaling_governor)\"; done"
        )
        for (line in cpuOut.lines()) {
            val idx = line.indexOf('=')
            if (idx <= 0) continue
            val policy = line.substring(0, idx)
            clean(line.substring(idx + 1))?.let { j.put("cpu_$policy", it) }
        }

        clean(RootShell.value("cat $GPU_GOV"))?.let { j.put("gpu", it) }

        for (key in ANIM) {
            j.put("anim_$key", clean(RootShell.value("settings get global $key")) ?: "1.0")
        }

        j.put("bright", clean(RootShell.value("settings get system screen_brightness")) ?: "128")
        j.put("bright_mode", clean(RootShell.value("settings get system screen_brightness_mode")) ?: "0")
        j.put("zen", clean(RootShell.value("settings get global zen_mode")) ?: "0")
        return j
    }

    /** Terapkan profil. Node yang tidak ada di kernel otomatis dilewati. */
    fun apply(prof: Profile) {
        val cmds = mutableListOf<String>()

        cmds += "for p in $CPU_BASE/policy*; do " +
            "grep -q ${prof.cpuGov} \$p/scaling_available_governors && " +
            "echo ${prof.cpuGov} > \$p/scaling_governor; done"

        cmds += "if grep -q ${prof.gpuGov} $GPU_AVAIL 2>/dev/null; then " +
            "echo ${prof.gpuGov} > $GPU_GOV; fi"

        for (key in ANIM) {
            cmds += "settings put global $key ${prof.animScale}"
        }

        prof.brightness?.let {
            cmds += "settings put system screen_brightness_mode 0"
            cmds += "settings put system screen_brightness $it"
        }

        if (prof.dnd) {
            cmds += "cmd notification set_dnd priority"
        }

        RootShell.run(cmds.joinToString("; "))
    }

    /** Kembalikan semua nilai dari snapshot. */
    fun restore(j: JSONObject) {
        val cmds = mutableListOf<String>()
        val keys = j.keys()
        while (keys.hasNext()) {
            val k = keys.next()
            val v = clean(j.optString(k)) ?: continue
            when {
                k.startsWith("cpu_") -> {
                    val path = "$CPU_BASE/${k.removePrefix("cpu_")}/scaling_governor"
                    cmds += "[ -w $path ] && echo $v > $path"
                }
                k == "gpu" -> cmds += "[ -w $GPU_GOV ] && echo $v > $GPU_GOV"
                k.startsWith("anim_") -> cmds += "settings put global ${k.removePrefix("anim_")} $v"
                k == "bright" -> cmds += "settings put system screen_brightness $v"
                k == "bright_mode" -> cmds += "settings put system screen_brightness_mode $v"
                k == "zen" -> cmds += "cmd notification set_dnd ${zenName(v)}"
            }
        }
        if (cmds.isNotEmpty()) RootShell.run(cmds.joinToString("; "))
    }

    private fun zenName(z: String): String = when (z) {
        "1" -> "priority"
        "2" -> "none"
        "3" -> "alarms"
        else -> "off"
    }

    /** Simpan snapshot (hanya kalau belum ada), lalu terapkan profil. */
    fun applyWithSnapshot(ctx: Context, prof: Profile) {
        if (Prefs.snapshot(ctx) == null) Prefs.saveSnapshot(ctx, capture())
        apply(prof)
    }

    /** Kembalikan setting awal dan hapus snapshot. */
    fun restoreWithSnapshot(ctx: Context) {
        Prefs.snapshot(ctx)?.let { restore(it) }
        Prefs.clearSnapshot(ctx)
        Prefs.setBoosting(ctx, false)
    }
}
