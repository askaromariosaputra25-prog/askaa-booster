package com.askaa.booster

/**
 * Profil performa. Nilai governor dan animasi akan dilewati otomatis
 * kalau kernel HP tidak mendukungnya (lihat Tuner.apply).
 */
enum class Profile(
    val label: String,
    val cpuGov: String,
    val gpuGov: String,
    val animScale: String,
    val brightness: Int?,
    val dnd: Boolean
) {
    PERFORMA("Performa", "performance", "performance", "0.5", null, true),
    SEIMBANG("Seimbang", "schedutil", "msm-adreno-tz", "1.0", null, true),
    HEMAT("Hemat", "powersave", "msm-adreno-tz", "1.0", 110, false)
}
