package com.askaa.booster

import java.io.InputStreamReader

data class ShellResult(val code: Int, val out: String)

/** Jalankan perintah sebagai root lewat `su -c`. Panggil dari thread IO. */
object RootShell {

    fun run(cmd: String): ShellResult {
        return try {
            val p = ProcessBuilder("su", "-c", cmd).redirectErrorStream(true).start()
            val out = InputStreamReader(p.inputStream).use { it.readText() }
            val code = p.waitFor()
            ShellResult(code, out.trim())
        } catch (e: Exception) {
            ShellResult(-1, e.message ?: "error")
        }
    }

    fun value(cmd: String): String = run(cmd).out

    fun hasRoot(): Boolean = run("id -u").out == "0"
}
