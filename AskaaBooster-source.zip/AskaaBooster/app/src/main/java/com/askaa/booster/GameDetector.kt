package com.askaa.booster

/** Mendeteksi app yang sedang di foreground lewat dumpsys (butuh root). */
object GameDetector {
    private val PKG = Regex("""u\d+\s+([A-Za-z0-9_.]+)/""")

    fun foreground(): String? {
        val out = RootShell.value(
            "dumpsys activity activities | grep -m1 mResumedActivity || " +
                "dumpsys window | grep -m1 mCurrentFocus"
        )
        return PKG.find(out)?.groupValues?.get(1)
    }
}
