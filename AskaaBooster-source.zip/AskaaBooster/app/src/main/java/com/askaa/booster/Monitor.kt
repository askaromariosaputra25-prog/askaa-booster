package com.askaa.booster

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import java.io.File

data class Stats(
    val tempC: Float?,
    val cpuMhz: Int?,
    val load: String,
    val ramUsedMb: Long,
    val ramTotalMb: Long,
    val batteryPct: Int?
)

object Monitor {
    private val SPACES = Regex("\\s+")

    fun readTemp(): Float? = thermalAndFreq().first

    fun read(ctx: Context): Stats {
        val (temp, mhz) = thermalAndFreq()
        val load = runCatching { File("/proc/loadavg").readText().split(" ")[0] }.getOrDefault("-")
        val (used, total) = runCatching { readMem() }.getOrDefault(0L to 0L)

        val battery = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = battery?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = battery?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
        val pct = if (level >= 0 && scale > 0) level * 100 / scale else null

        return Stats(temp, mhz, load, used, total, pct)
    }

    /** Suhu tertinggi yang masuk akal (dalam °C) dan frekuensi CPU tertinggi (MHz). */
    private fun thermalAndFreq(): Pair<Float?, Int?> {
        val out = RootShell.value(
            "cat /sys/class/thermal/thermal_zone*/temp 2>/dev/null; echo ---; " +
                "cat /sys/devices/system/cpu/cpufreq/policy*/scaling_cur_freq 2>/dev/null"
        )
        val parts = out.split("---")
        val temps = parts.getOrElse(0) { "" }.lines()
            .mapNotNull { it.trim().toIntOrNull() }
            .filter { it in 1000..120000 }
        val freqs = parts.getOrElse(1) { "" }.lines().mapNotNull { it.trim().toIntOrNull() }

        val tempC = temps.maxOrNull()?.let { it / 1000f }
        val mhz = freqs.maxOrNull()?.let { it / 1000 }
        return tempC to mhz
    }

    private fun readMem(): Pair<Long, Long> {
        val map = File("/proc/meminfo").readLines().associate { line ->
            val parts = line.trim().split(SPACES)
            parts[0].removeSuffix(":") to (parts.getOrNull(1)?.toLongOrNull() ?: 0L)
        }
        val total = (map["MemTotal"] ?: 0L) / 1024
        val avail = (map["MemAvailable"] ?: 0L) / 1024
        return (total - avail) to total
    }
}
