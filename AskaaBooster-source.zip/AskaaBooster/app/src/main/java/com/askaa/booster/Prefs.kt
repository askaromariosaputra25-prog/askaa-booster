package com.askaa.booster

import android.content.Context
import org.json.JSONObject

object Prefs {
    private const val FILE = "askaa_prefs"
    private const val K_GAMES = "games"
    private const val K_AUTO = "auto_boost"
    private const val K_PROFILE = "profile"
    private const val K_SNAPSHOT = "snapshot"
    private const val K_BOOSTING = "boosting"

    private fun sp(ctx: Context) = ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun games(ctx: Context): Set<String> =
        HashSet(sp(ctx).getStringSet(K_GAMES, emptySet()) ?: emptySet())

    fun setGames(ctx: Context, games: Set<String>) {
        sp(ctx).edit().putStringSet(K_GAMES, HashSet(games)).apply()
    }

    fun autoBoost(ctx: Context): Boolean = sp(ctx).getBoolean(K_AUTO, false)

    fun setAutoBoost(ctx: Context, on: Boolean) {
        sp(ctx).edit().putBoolean(K_AUTO, on).apply()
    }

    fun profile(ctx: Context): Profile {
        val name = sp(ctx).getString(K_PROFILE, Profile.SEIMBANG.name) ?: Profile.SEIMBANG.name
        return runCatching { Profile.valueOf(name) }.getOrDefault(Profile.SEIMBANG)
    }

    fun setProfile(ctx: Context, p: Profile) {
        sp(ctx).edit().putString(K_PROFILE, p.name).apply()
    }

    fun snapshot(ctx: Context): JSONObject? =
        sp(ctx).getString(K_SNAPSHOT, null)?.let { runCatching { JSONObject(it) }.getOrNull() }

    fun saveSnapshot(ctx: Context, j: JSONObject) {
        sp(ctx).edit().putString(K_SNAPSHOT, j.toString()).apply()
    }

    fun clearSnapshot(ctx: Context) {
        sp(ctx).edit().remove(K_SNAPSHOT).apply()
    }

    /** True kalau auto-boost sedang menahan setting (dipakai untuk pemulihan setelah crash). */
    fun boosting(ctx: Context): Boolean = sp(ctx).getBoolean(K_BOOSTING, false)

    fun setBoosting(ctx: Context, on: Boolean) {
        sp(ctx).edit().putBoolean(K_BOOSTING, on).apply()
    }
}
