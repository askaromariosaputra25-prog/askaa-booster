package com.askaa.booster

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun HomeScreen(onPickGames: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val scroll = rememberScrollState()

    var rootOk by remember { mutableStateOf<Boolean?>(null) }
    var auto by remember { mutableStateOf(Prefs.autoBoost(ctx)) }
    var profile by remember { mutableStateOf(Prefs.profile(ctx)) }
    var hasSnapshot by remember { mutableStateOf(Prefs.snapshot(ctx) != null) }
    var gameCount by remember { mutableStateOf(Prefs.games(ctx).size) }
    var stats by remember { mutableStateOf<Stats?>(null) }
    var msg by remember { mutableStateOf("") }

    val notifPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }

    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33) notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
        rootOk = withContext(Dispatchers.IO) { RootShell.hasRoot() }
        while (true) {
            stats = withContext(Dispatchers.IO) { Monitor.read(ctx) }
            hasSnapshot = Prefs.snapshot(ctx) != null
            gameCount = Prefs.games(ctx).size
            delay(3000)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scroll)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Askaa Booster", style = MaterialTheme.typography.headlineMedium)

        if (rootOk == false) {
            Text(
                "Root tidak terdeteksi. Tuning tidak akan berjalan.",
                color = MaterialTheme.colorScheme.error
            )
        }

        Section("Booster otomatis") {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("Aktifkan saat game dibuka")
                    Text("Game dipilih lewat tombol di bawah", style = MaterialTheme.typography.bodySmall)
                }
                Switch(
                    checked = auto,
                    onCheckedChange = { on ->
                        auto = on
                        Prefs.setAutoBoost(ctx, on)
                        if (on) BoostService.start(ctx) else BoostService.stop(ctx)
                    }
                )
            }
            OutlinedButton(onClick = onPickGames, modifier = Modifier.fillMaxWidth()) {
                Text("Pilih game ($gameCount dipilih)")
            }
        }

        Section("Profil") {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Profile.entries.forEach { p ->
                    val onClick = {
                        profile = p
                        Prefs.setProfile(ctx, p)
                    }
                    if (p == profile) {
                        Button(onClick = onClick, modifier = Modifier.weight(1f)) { Text(p.label) }
                    } else {
                        OutlinedButton(onClick = onClick, modifier = Modifier.weight(1f)) { Text(p.label) }
                    }
                }
            }
            Button(
                onClick = {
                    scope.launch {
                        withContext(Dispatchers.IO) { Tuner.applyWithSnapshot(ctx, profile) }
                        hasSnapshot = true
                        msg = "Profil ${profile.label} diterapkan"
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Terapkan sekarang") }
            OutlinedButton(
                onClick = {
                    scope.launch {
                        withContext(Dispatchers.IO) { Tuner.restoreWithSnapshot(ctx) }
                        hasSnapshot = false
                        msg = "Setting awal dikembalikan"
                    }
                },
                enabled = hasSnapshot,
                modifier = Modifier.fillMaxWidth()
            ) { Text("Kembalikan setting awal") }
        }

        Section("Monitor") {
            val s = stats
            Text("Suhu: ${s?.tempC?.let { "%.1f°C".format(it) } ?: "-"}")
            Text("CPU maks: ${s?.cpuMhz?.let { "$it MHz" } ?: "-"}")
            Text("Load: ${s?.load ?: "-"}")
            Text("RAM: ${s?.ramUsedMb ?: 0} / ${s?.ramTotalMb ?: 0} MB")
            Text("Baterai: ${s?.batteryPct?.let { "$it%" } ?: "-"}")
        }

        Section("Bersihkan") {
            OutlinedButton(
                onClick = {
                    scope.launch {
                        withContext(Dispatchers.IO) { RootShell.run("am kill-all") }
                        msg = "Background app dibersihkan"
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Bersihkan background") }
        }

        if (msg.isNotEmpty()) {
            Spacer(modifier = Modifier.height(4.dp))
            Text(msg, style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
private fun Section(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            content()
        }
    }
}
