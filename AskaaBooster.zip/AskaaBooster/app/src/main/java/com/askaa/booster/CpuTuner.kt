package com.askaa.booster

/**
 * Mengatur governor CPU per cluster (policy).
 * Hanya menulis nilai yang memang tersedia di HP ini, dan selalu bisa dikembalikan dari snapshot.
 */
object CpuTuner {

    private const val POLICY_GLOB = "/sys/devices/system/cpu/cpufreq/policy*"

    /** Mencatat governor saat ini untuk tiap cluster, sebagai titik kembali. */
    fun snapshot(): Map<String, String> {
        val out = RootShell.run(
            "for p in $POLICY_GLOB; do echo \"\$p|\$(cat \$p/scaling_governor)\"; done"
        ) ?: return emptyMap()

        return out.lines()
            .filter { it.contains('|') }
            .associate { line ->
                val parts = line.split('|', limit = 2)
                parts[0].trim() to parts[1].trim()
            }
            .filterValues { it.isNotEmpty() }
    }

    /** Mengubah governor hanya di cluster yang mendukungnya. Mengembalikan jumlah cluster yang berhasil. */
    fun apply(governor: String, policies: Collection<String>): Int {
        var changed = 0
        for (policy in policies) {
            val available = RootShell.run("cat $policy/scaling_available_governors") ?: continue
            if (governor !in available.trim().split(Regex("\\s+"))) continue
            if (RootShell.run("echo $governor > $policy/scaling_governor") != null) changed++
        }
        return changed
    }

    /** Mengembalikan governor sesuai snapshot. True jika semua cluster berhasil dikembalikan. */
    fun restore(snapshot: Map<String, String>): Boolean {
        var allOk = true
        for ((policy, governor) in snapshot) {
            if (RootShell.run("echo $governor > $policy/scaling_governor") == null) allOk = false
        }
        return allOk
    }
}
