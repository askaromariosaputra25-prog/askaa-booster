package com.askaa.booster

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.askaa.booster.databinding.ActivityMainBinding
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val main = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()
    private var rootText = "belum dicek"

    private val refresher = object : Runnable {
        override fun run() {
            refreshStatus()
            main.postDelayed(this, 2000L)
        }
    }

    private val notifPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { startBooster() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnRoot.setOnClickListener { checkRoot() }
        binding.btnUsage.setOnClickListener {
            startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
        }
        binding.btnStart.setOnClickListener { startBooster() }
        binding.btnStop.setOnClickListener { stopBooster() }
        binding.btnGames.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
    }

    override fun onResume() {
        super.onResume()
        main.post(refresher)
    }

    override fun onPause() {
        super.onPause()
        main.removeCallbacks(refresher)
    }

    override fun onDestroy() {
        worker.shutdownNow()
        super.onDestroy()
    }

    private fun checkRoot() {
        rootText = "mengecek..."
        refreshStatus()
        worker.execute {
            val ok = RootShell.hasRoot()
            main.post {
                rootText = if (ok) "ya" else "tidak terdeteksi"
                refreshStatus()
            }
        }
    }

    private fun startBooster() {
        if (!Device.hasUsageAccess(this)) {
            toast("Izinkan pemakaian data dulu, lalu kembali ke sini")
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
            return
        }
        ContextCompat.startForegroundService(this, Intent(this, BoostService::class.java))
        toast("Booster aktif. Silakan buka game kamu.")
    }

    private fun stopBooster() {
        stopService(Intent(this, BoostService::class.java))
        toast("Booster dimatikan. Setting dikembalikan.")
        main.postDelayed({ refreshStatus() }, 1000L)
    }

    private fun refreshStatus() {
        binding.rootValue.text = rootText
        binding.usageValue.text =
            if (Device.hasUsageAccess(this)) "sudah diizinkan" else "belum diizinkan"
        binding.tempValue.text = String.format("%.1f °C", Device.batteryTempC(this))
        binding.boostValue.text = if (Prefs.isBoosted(this)) "aktif" else "tidak aktif"
        binding.statusValue.text = Prefs.status(this)
    }

    private fun toast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }
}
