package com.askaa.booster

/** Menjalankan perintah lewat su (root). Mengembalikan output jika berhasil, null jika gagal. */
object RootShell {

    fun run(command: String): String? {
        return try {
            val process = Runtime.getRuntime().exec(arrayOf("su", "-c", command))
            val output = process.inputStream.bufferedReader().use { it.readText() }
            process.errorStream.bufferedReader().use { it.readText() }
            if (process.waitFor() == 0) output else null
        } catch (e: Exception) {
            null
        }
    }

    fun hasRoot(): Boolean = run("id -u")?.trim() == "0"
}
