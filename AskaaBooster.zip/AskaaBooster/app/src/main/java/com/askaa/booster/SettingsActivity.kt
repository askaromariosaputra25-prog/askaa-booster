package com.askaa.booster

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.askaa.booster.databinding.ActivitySettingsBinding

class SettingsActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySettingsBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.gameInput.setText(Prefs.games(this).sorted().joinToString("\n"))

        binding.saveButton.setOnClickListener {
            val list = binding.gameInput.text.toString()
                .lines()
                .map { it.trim() }
                .filter { it.isNotEmpty() }
            if (list.isEmpty()) {
                Toast.makeText(this, "Isi minimal satu nama paket game", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            Prefs.saveGames(this, list)
            Toast.makeText(this, "Daftar game tersimpan", Toast.LENGTH_SHORT).show()
            finish()
        }
    }
}
