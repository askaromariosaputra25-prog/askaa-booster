package com.askaa.booster

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.os.IBinder
import androidx.core.app.NotificationCompat
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/**
 * Berjalan di latar belakang dan memantau app yang sedang dibuka.
 * - Game terbuka dan suhu aman: governor CPU dinaikkan ke "performance".
 * - Game ditutup, atau suhu mencapai batas: setting awal dikembalikan.
 * - Setiap tick mengecek sisa sesi sebelumnya, jadi setting tidak tertinggal kalau app sempat mati.
 */
class BoostService : Service() {

    private val lock = Any()
    private val executor = Executors.newSingleThreadScheduledExecutor()
    private var started = false
    private var foreground: String? = null
    private var lastQuery = 0L
    private var lastFailAt = 0L

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createChannel()
        lastQuery = System.currentTimeMillis() - 60_000L
        startForeground(NOTIF_ID, buildNotification("memulai..."))
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!started) {
            started = true
            executor.scheduleWithFixedDelay({ safeTick() }, 0L, 3L, TimeUnit.SECONDS)
        }
        return START_STICKY
    }

    override fun onDestroy() {
        executor.shutdown()
        // Kembalikan setting di thread terpisah, supaya tidak memblokir UI
        Thread {
            synchronized(lock) {
                restoreIfNeeded()
                Prefs.saveStatus(this, "booster mati, setting dikembalikan")
            }
        }.start()
        super.onDestroy()
    }

    private fun safeTick() {
        try {
            synchronized(lock) { tick() }
        } catch (e: Throwable) {
            Prefs.saveStatus(this, "terjadi error: ${e.message ?: "tidak diketahui"}")
        }
    }

    private fun tick() {
        if (!Device.hasUsageAccess(this)) {
            restoreIfNeeded()
            Prefs.saveStatus(this, "izin pemakaian data belum diberikan")
            return
        }

        updateForeground(System.currentTimeMillis())
        val fg = foreground
        val isGame = fg != null && fg in Prefs.games(this)
        val temp = Device.batteryTempC(this)
        val boosted = Prefs.isBoosted(this)

        when {
            // Sisa sesi sebelumnya belum berhasil dikembalikan
            !boosted && Prefs.hasSnapshot(this) -> restoreIfNeeded()

            boosted && (!isGame || temp >= TEMP_STOP) -> {
                val ok = restoreIfNeeded()
                val reason = when {
                    !ok -> "gagal mengembalikan, akan dicoba lagi"
                    temp >= TEMP_STOP -> "suhu tinggi, setting dikembalikan"
                    else -> "game ditutup, setting dikembalikan"
                }
                Prefs.saveStatus(this, reason)
            }

            !boosted && isGame && temp < TEMP_START -> boost()

            !boosted && isGame -> Prefs.saveStatus(this, "menunggu suhu turun di bawah 40 °C")

            else -> if (!boosted) Prefs.saveStatus(this, "menunggu game")
        }

        updateNotification(Prefs.status(this))
    }

    private fun updateForeground(now: Long) {
        val usm = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val events = usm.queryEvents(lastQuery, now)
        val event = UsageEvents.Event()
        while (events.hasNextEvent()) {
            events.getNextEvent(event)
            when (event.eventType) {
                UsageEvents.Event.MOVE_TO_FOREGROUND -> foreground = event.packageName
                UsageEvents.Event.MOVE_TO_BACKGROUND -> {
                    if (event.packageName == foreground) foreground = null
                }
            }
        }
        lastQuery = now
    }

    private fun boost() {
        if (System.currentTimeMillis() - lastFailAt < RETRY_MS) {
            Prefs.saveStatus(this, "menunggu sebelum mencoba lagi")
            return
        }

        val snapshot = CpuTuner.snapshot()
        if (snapshot.isEmpty()) {
            lastFailAt = System.currentTimeMillis()
            Prefs.saveStatus(this, "akses root tidak tersedia atau governor tidak terbaca")
            return
        }

        // Simpan titik kembali dulu, baru ubah
        Prefs.saveSnapshot(this, snapshot)
        val changed = CpuTuner.apply(GOVERNOR_BOOST, snapshot.keys)
        if (changed == 0) {
            restoreIfNeeded()
            lastFailAt = System.currentTimeMillis()
            Prefs.saveStatus(this, "HP ini tidak mengizinkan mode performa")
            return
        }

        Prefs.setBoosted(this, true)
        Prefs.saveStatus(this, "aktif untuk game")
    }

    /** Mengembalikan governor dari snapshot. Snapshot dihapus hanya jika berhasil. */
    private fun restoreIfNeeded(): Boolean {
        val snapshot = Prefs.loadSnapshot(this)
        val ok = snapshot.isEmpty() || CpuTuner.restore(snapshot)
        if (ok) Prefs.clearSnapshot(this)
        Prefs.setBoosted(this, false)
        return ok
    }

    private fun createChannel() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Askaa Booster", NotificationManager.IMPORTANCE_LOW)
        )
    }

    private fun updateNotification(text: String) {
        getSystemService(NotificationManager::class.java).notify(NOTIF_ID, buildNotification(text))
    }

    private fun buildNotification(text: String): Notification =
        NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Askaa Booster")
            .setContentText(text)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .build()

    companion object {
        private const val CHANNEL_ID = "askaa_booster"
        private const val NOTIF_ID = 1
        private const val GOVERNOR_BOOST = "performance"
        private const val TEMP_START = 40.0
        private const val TEMP_STOP = 43.0
        private const val RETRY_MS = 60_000L
    }
}
