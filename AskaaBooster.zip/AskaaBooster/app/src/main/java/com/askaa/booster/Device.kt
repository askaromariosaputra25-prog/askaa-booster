package com.askaa.booster

import android.app.AppOpsManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Process

object Device {

    /** True jika izin "Akses penggunaan" sudah diberikan ke app ini. */
    fun hasUsageAccess(context: Context): Boolean {
        val appOps = context.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        @Suppress("DEPRECATION")
        val mode = appOps.checkOpNoThrow(
            AppOpsManager.OPSTR_GET_USAGE_STATS,
            Process.myUid(),
            context.packageName
        )
        return mode == AppOpsManager.MODE_ALLOWED
    }

    /** Suhu baterai dalam derajat Celsius. Mengembalikan 0 jika tidak terbaca. */
    fun batteryTempC(context: Context): Double {
        val intent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            ?: return 0.0
        return intent.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) / 10.0
    }
}
