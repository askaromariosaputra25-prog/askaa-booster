package com.askaa.booster

import android.content.Context
import org.json.JSONObject

object Prefs {

    private const val FILE = "askaa_booster"
    private const val KEY_GAMES = "games"
    private const val KEY_BOOSTED = "boosted"
    private const val KEY_SNAPSHOT = "snapshot"
    private const val KEY_STATUS = "status"

    /** Daftar awal nama paket game. Bisa diubah di menu daftar game. */
    val DEFAULT_GAMES = setOf(
        "com.mobile.legends",
        "com.miHoYo.GenshinImpact",
        "com.tencent.ig",
        "com.dts.freefireth",
        "com.dts.freefiremax"
    )

    private fun prefs(context: Context) =
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun games(context: Context): Set<String> =
        prefs(context).getStringSet(KEY_GAMES, null)?.toSet() ?: DEFAULT_GAMES

    fun saveGames(context: Context, list: Collection<String>) {
        prefs(context).edit().putStringSet(KEY_GAMES, list.toSet()).apply()
    }

    fun isBoosted(context: Context): Boolean =
        prefs(context).getBoolean(KEY_BOOSTED, false)

    fun setBoosted(context: Context, value: Boolean) {
        prefs(context).edit().putBoolean(KEY_BOOSTED, value).apply()
    }

    fun hasSnapshot(context: Context): Boolean =
        prefs(context).contains(KEY_SNAPSHOT)

    fun saveSnapshot(context: Context, snapshot: Map<String, String>) {
        val json = JSONObject()
        snapshot.forEach { (policy, governor) -> json.put(policy, governor) }
        prefs(context).edit().putString(KEY_SNAPSHOT, json.toString()).apply()
    }

    fun loadSnapshot(context: Context): Map<String, String> {
        val raw = prefs(context).getString(KEY_SNAPSHOT, null) ?: return emptyMap()
        return try {
            val json = JSONObject(raw)
            json.keys().asSequence().associateWith { json.getString(it) }
        } catch (e: Exception) {
            emptyMap()
        }
    }

    fun clearSnapshot(context: Context) {
        prefs(context).edit().remove(KEY_SNAPSHOT).apply()
    }

    fun saveStatus(context: Context, text: String) {
        prefs(context).edit().putString(KEY_STATUS, text).apply()
    }

    fun status(context: Context): String =
        prefs(context).getString(KEY_STATUS, null) ?: "belum aktif"
}
