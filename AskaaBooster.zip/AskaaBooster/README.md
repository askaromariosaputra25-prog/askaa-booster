# Askaa Booster

Booster untuk HP Android yang sudah di-root. Saat game dari daftar terbuka, governor CPU dinaikkan ke mode performa. Saat game ditutup atau suhu baterai mencapai 43 °C, setting kembali ke nilai awal.

## Syarat
- HP sudah root (Magisk atau sejenisnya), dan app ini sudah diizinkan di sana.
- Izin "Akses penggunaan" untuk Askaa Booster sudah diberikan (tombol izinkan pemakaian data di app).

## Cara kerja
1. Saat diaktifkan, app mencatat governor CPU awal setiap cluster.
2. Saat game terdeteksi dan suhu di bawah 40 °C, governor diubah ke `performance`, hanya di cluster yang mendukungnya.
3. Saat game ditutup, atau suhu mencapai 43 °C, governor dikembalikan dari catatan awal.
4. Kalau app sempat mati di tengah sesi, setting dikembalikan saat app dibuka atau berjalan lagi.

## Batasan
- Tidak menjamin FPS naik. Hasilnya tergantung HP, dan sistem bisa membatasi perubahan.
- Mode performa membuat HP lebih panas dan lebih cepat habis baterainya.

## Mengubah daftar game
Menu "daftar game" di app. Isi satu nama paket per baris.

## Build dari HP
Buat repository `AskaaBooster`, tambahkan `.github/workflows/build.yml`, upload `AskaaBooster.zip`, lalu jalankan workflow Build APK.
